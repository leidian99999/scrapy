from urllib.request import urlopen, quote
import requests
import json

def getlnglat(address):
	"""根据传入地名参数获取经纬度"""
	url = 'http://api.map.baidu.com/geocoder/v2/'
	output = 'json'#输出数据的格式
	ak = '申请的密钥'
	add = quote(address) #由于本文地址变量为中文，为防止乱码，先用quote进行编码
	uri = url + '?' + 'address=' + add  + '&output=' + output + '&ak=' + ak 
	req = urlopen(uri)
	res = req.read().decode() 
	temp = json.loads(res)
	lat=temp['result']['location']['lat']
	lng=temp['result']['location']['lng']
	return lat,lng
def __jsonDump(name,_json):
	"""传入保存路径和字典参数，保存数据到对应的文件中"""
	with open(name + '.json','a') as outfile:
		json.dump(_json,outfile,ensure_ascii=False)
	with open(name + '.json','a') as outfile:
		outfile.write(',\n')
if __name__ == '__main__':
	file=open(r"C:\Users\MaMQ\hrFood.json",encoding='utf-8')
	data=[]
	newData=[]
	for line in file:
		data.append(json.loads(line[:-2]))
	for dic in data:
		address=dic['地址']
		lat,lng=getlnglat(address)
		dic['lat']=lat
		dic['lng']=lng
		newData.append(dic)
	for dic in newData:
		__jsonDump("HuaiRou",dic)